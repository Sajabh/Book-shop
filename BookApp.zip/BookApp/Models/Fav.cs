﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookApp.Models
{
    public class Fav
    {
        [Key]
        
        [Required(ErrorMessage = "Please enter a book ID.")]
        public int? BookId { get; set; }

        [Required(ErrorMessage = "Please enter a name.")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a writer.")]
        public string Writer { get; set; } = string.Empty;


        [Required(ErrorMessage = "Please enter a date.")]
        public string Date { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a URL.")]
        public string URL { get; set; } = string.Empty;

        public User User { get; set; } = null!;
        public int? UserId { get;  set; }
    }
}
