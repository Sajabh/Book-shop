﻿using Microsoft.EntityFrameworkCore; //use this package because DbContext is installed with it

namespace BookApp.Models
{
    public class BookContext : DbContext
    {
        public BookContext(DbContextOptions<BookContext> options) : base(options)
        { }

        public DbSet<Book> Books { get; set; } = null!;
        public DbSet<Fav> Favs { get; set; } = null!;
        public DbSet<Admin> Admin { get; set; } = null!;
        public DbSet<User> Users { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Book>().HasData(
                new Book
                {
                    BookId = 1,
                    Name = "The book of the people",
                    Writer = "Tsahor, Dan",
                    Date = "2023",
                    URL = "https://www.nypl.org/research/research-catalog/bib/b23226626?originalUrl=https%3A%2F%2Fcatalog.nypl.org%2Frecord%3Db23226626%3Flang%3Deng%26source%3DNewArrivals"
                }
                                                );
        }
                


    }

}



    



  

        

        