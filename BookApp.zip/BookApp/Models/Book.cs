﻿using System.ComponentModel.DataAnnotations;

namespace BookApp.Models
{
    public class Book
    {
        
        public int? BookId { get; set; }

        [Required(ErrorMessage = "Please enter a name.")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a writer.")]
        public string Writer { get; set; } = string.Empty;

        
        [Required(ErrorMessage = "Please enter a date.")]
        public string Date { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a URL.")]
        public string URL { get; set; } = string.Empty;


    }
}
