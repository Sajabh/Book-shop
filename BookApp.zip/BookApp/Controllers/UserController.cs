﻿using BookApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using Microsoft.AspNetCore.Http;
using System.Net.Http;

namespace BookApp.Controllers
{
    public class UserController : Controller
    {
        private BookContext context { get; set; }

        public UserController(BookContext ctx) => context = ctx;

        public IActionResult BookListUser()
        {
            if (HttpContext.Session.GetInt32("Uid") == null)
                return RedirectToAction("Login", "Home");

            var books = context.Books.OrderBy(b => b.Name).ToList();

            return View(books);

        }

        public IActionResult UserSearch(string searchKey)
        {
            if (HttpContext.Session.GetInt32("Uid") == null)
                return RedirectToAction("Login", "Home");

            var BookList = context.Books.Where(b => b.Name.Contains(searchKey)).OrderBy(b => b.Name).ToList();
            return View("BookListUser", BookList);

        }

        [HttpGet]
        public IActionResult UserChangePassword()
        {
            if (HttpContext.Session.GetInt32("Uid") == null)
                return RedirectToAction("Login", "Home");

            return View();
        }

        [HttpPost]
        public IActionResult UserChangePassword(string oldPass, string newPass)
        {
            int? Uid = HttpContext.Session.GetInt32("Uid");
            User user = context.Users.Find(Uid);
            if (user.Password == oldPass)
            {
                user.Password = newPass;
                context.Users.Update(user);
                context.SaveChanges();
                return RedirectToAction("BookListUser", "User");
            }
            return View();
        }

        public IActionResult AddFav(int id)
        {
            if (HttpContext.Session.GetInt32("Uid") == null)
                return RedirectToAction("Login", "Home");

            Book B = context.Books.Where(b=>b.BookId==id).FirstOrDefault();
            List<Fav> Favs = context.Favs.Where(f => f.UserId == HttpContext.Session.GetInt32("Uid")).ToList();
            foreach(Fav f in Favs)
            {
                if(f.Name==B.Name && f.Writer==B.Writer && f.Date==B.Date && f.URL==B.URL)
                {
                    ViewBag.Error_fav = "This book is already exist in Favourite List ";
                    return RedirectToAction("BookListUser", "User");
                }
            }
            ViewBag.Error_fav = null;
            Fav ff = new Fav();
            ff.Name = B.Name;
            ff.Writer = B.Writer;
            ff.Date = B.Date;
            ff.URL = B.URL;
            ff.UserId = HttpContext.Session.GetInt32("Uid");
            context.Favs.Add(ff);
            context.SaveChanges();
            return RedirectToAction("BookListUser", "User");
        }


        public IActionResult FavList()
        {
            if (HttpContext.Session.GetInt32("Uid") == null)
                return RedirectToAction("Login", "Home");
            else
            {
                int? UserID = HttpContext.Session.GetInt32("Uid");
                List<Fav> Fav = context.Favs.Where(f => f.UserId == UserID).ToList();
                return View(Fav);

            }

        }

        public IActionResult DeleteFav(int id)
        {
            if (HttpContext.Session.GetInt32("Uid") == null)
                return RedirectToAction("Login", "Home");

            int? UserID = HttpContext.Session.GetInt32("Uid");
            Fav f = context.Favs.Where(b => b.BookId == id && b.UserId == UserID).FirstOrDefault();
            context.Favs.Remove(f);
            context.SaveChanges();
            return RedirectToAction("FavList", "User");

        }
    }
}