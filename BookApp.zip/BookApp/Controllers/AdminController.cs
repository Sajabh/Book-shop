﻿using Microsoft.AspNetCore.Mvc;
using BookApp.Models;
using System.Net;
using Microsoft.AspNetCore.Http;
using System.Net.Http;

namespace BookApp.Controllers
{
    public class AdminController : Controller
    {
        private BookContext context { get; set; }

        public AdminController(BookContext ctx) => context = ctx;



        public IActionResult BookListAdmin()
        {
            if (HttpContext.Session.GetInt32("Aid") == null)
                return View("Login");

            var books = context.Books.OrderBy(b => b.Name).ToList();

            return View(books);
        }

        [HttpGet]
        public IActionResult Add()
        {
            if (HttpContext.Session.GetInt32("Aid") == null)
                return RedirectToAction("Login", "Home");

            return View();
        }

        [HttpPost]
        public IActionResult Add(Book B)
        {
            if (HttpContext.Session.GetInt32("Aid") == null)
                return RedirectToAction("Login", "Home");
            if(ModelState.IsValid)
            {

                context.Books.Add(B);
                context.SaveChanges();
                return RedirectToAction("BookListAdmin", "Admin");
            }
            return View();
        }

        public IActionResult AdminSearch(string searchKey)
        {
            
            if (HttpContext.Session.GetInt32("Aid") != null)
            {
                var BookList = context.Books.Where(b => b.Name.Contains(searchKey)).OrderBy(b => b.Name).ToList();
                return View("BookListAdmin", BookList);

            }

            return RedirectToAction("Login", "Home");

        }

        [HttpGet]
        public IActionResult AdminChangePassword()
        {
             if (HttpContext.Session.GetInt32("Aid") == null)
                return RedirectToAction("Login","Home");

            return View();
        }

        [HttpPost]
        public IActionResult AdminChangePassword(string oldPass, string newPass)
        {
            int? Aid = HttpContext.Session.GetInt32("Aid");
            Admin admin = context.Admin.Find(Aid);
            if(admin.Password==oldPass)
            {
                admin.Password = newPass;
                ViewBag.Error = null;
                context.Admin.Update(admin);
                context.SaveChanges();
                return RedirectToAction("BookListAdmin", "Admin");
            }
            ViewBag.Error = "The Old Password is Wrong";
            return View();
            
        }

        public IActionResult DeleteBook(int id)  
        {
            if (HttpContext.Session.GetInt32("Aid") == null)
                return RedirectToAction("Login", "Home");

            Book book = context.Books.Where(b => b.BookId == id).FirstOrDefault();
            context.Remove(book);
            context.SaveChanges();
            return RedirectToAction("BookListAdmin", "Admin");
        }

        [HttpGet]
        public IActionResult EditBook(int id)
        {
            if (HttpContext.Session.GetInt32("Aid") == null)
                return RedirectToAction("Login", "Home");

            
            var book = context.Books.Find(id);
            return View(book);
        }

        [HttpPost]
        public IActionResult EditBook(Book book)
        {
            if (ModelState.IsValid)
            {
                
                        context.Books.Update(book);
                        context.SaveChanges();
                        return RedirectToAction("BookListAdmin", "Admin");
                    
                
            }
            return View();
        }


    }
}
