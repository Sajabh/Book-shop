using Microsoft.AspNetCore.Mvc;
using BookApp.Models;
using System.Net;
using Microsoft.AspNetCore.Http;
using System.Net.Http;

namespace BookApp.Controllers
{
    public class HomeController : Controller
    {
        private BookContext context { get; set; }

        public HomeController(BookContext ctx) => context = ctx;


        [HttpGet]
        public IActionResult Login()
        {

            if (HttpContext.Session.GetInt32("Uid") != null)
            { return RedirectToAction("BookListUser", "User"); }

            else if (HttpContext.Session.GetInt32("Aid") !=null)
            { return RedirectToAction("BookListAdmin", "Admin"); }

            return View();
     
        }

        [HttpPost]
        public IActionResult Login(string Uname, string Upass,int Flag)
        {
          
            if (Flag==1)//This is Admin
            {
                Admin admin = context.Admin.Where(a => a.UserName == Uname && a.Password == Upass).FirstOrDefault();
                if (admin != null)
                {
                    //successful login
                    HttpContext.Session.SetInt32("Aid", admin.AdminId);
                    return RedirectToAction("BookListAdmin", "Admin");
                }
                return View("Login");
                
               
            }
            else if (Flag == 0)//This is user
            {
                User user = context.Users.Where(u => u.UserName == Uname && u.Password == Upass).FirstOrDefault();
                if (user != null)
                {
                    //successful login
                    HttpContext.Session.SetInt32("Uid", user.UserId);
                    ViewBag.UserName = user.UserName;
                    return RedirectToAction("BookListUser", "User");
                }  
                
                 return View("Login");
                
            }

            else
                return View("Login");

        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return View("Login");
        }

       

        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SignUp(User user)
        {
            
            
                if (context.Users.Any(u => u.UserName == user.UserName
                               && u.Email == user.Email
                               && u.Password == user.Password))
                {
                    ViewBag.Notification = "This account has already existed";
                    user.Flag = 1;
                    return View(user);
                }
                else
                {
                    context.Users.Add(user);
                    context.SaveChanges();
                    HttpContext.Session.SetInt32("Uid", user.UserId);
                    return RedirectToAction("BookListUser", "User");
                }

            

            
            
            
        }





    }
}
